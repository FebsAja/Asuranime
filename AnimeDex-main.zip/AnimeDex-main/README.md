## ⚠️ Note: This project is no longer managed. Use [AnimeDexLite](https://github.com/TechShreyash/AnimeDexLite) Instead

AnimeDexLite is a new version of AnimeDex built using html, css and js
- Repo : https://github.com/TechShreyash/AnimeDexLite




### 👤 Contact Me

[![Telegram Channel](https://img.shields.io/static/v1?label=Join&message=Telegram%20Channel&color=blueviolet&style=for-the-badge&logo=telegram&logoColor=violet)](https://telegram.me/TechZBots) [![Telegram Group](https://img.shields.io/static/v1?label=Join&message=Telegram%20Group&color=blueviolet&style=for-the-badge&logo=telegram&logoColor=violet)](https://telegram.me/TechZBots_Support)
