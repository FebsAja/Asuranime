# Security Policy

## Supported Versions

| Version | Supported          |
| ------- | ------------------ |
| 1.5.x   | :white_check_mark: |
| < 1.5.1   | :x:                |

## Reporting a Vulnerability

Report Vulnerability To Us On Our Official Telegram Group https://t.me/TechZBots_Support

Or Create A Issue In This Repo
